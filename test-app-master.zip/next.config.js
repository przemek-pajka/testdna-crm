/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    domains: ['demos.pixinvent.com'],
  },
}

module.exports = nextConfig